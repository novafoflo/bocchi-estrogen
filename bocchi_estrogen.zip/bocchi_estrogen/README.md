# Estrogen: Bocchi (NeoForge 1.21.1)
Eat the Estrogen pill (or the built-in Bocchi Pill) -> Bocchi effect:
pink hair, pink tracksuit jacket, growing bust (stacks up to 4 doses),
Haste when alone, Slowness when another player is within 10 blocks.

## Build
Easiest: copy `src/` into the official NeoForge MDK (github.com/NeoForgeMDKs/MDK-1.21.1-ModDevGradle),
keep its Gradle wrapper, then `./gradlew build` -> jar in build/libs.
Or use the included build.gradle with Gradle 8.10+ and JDK 21.

## IMPORTANT
Set `triggerItem` in config/bocchi_estrogen-common.toml to Estrogen's real pill ID.
The default `estrogen:estrogen_pill` is a guess.
